﻿namespace Diagnóstico_Médico
{
    internal class DecisionTreeEval
    {
    }
}